import java.util.*;

public class EjercicioIndividual20 {

    /**
     * @author Bastián Mariángel
     */


    public static void main(String[] args) {


        List<Float> numeros = new ArrayList<>();
        Scanner leer = new Scanner(System.in);
        float num;
        double promedio = 0;
        float menorNota = Float.MAX_VALUE;
        float mayorNota = Float.MIN_VALUE;

        do {
            System.out.println("Ingrese un numero");
            num = leer.nextFloat();

            if (num != 0) {
                numeros.add(num);
            }


        } while (num != 0);

        promedio = numeros.stream().mapToDouble(e -> e).average().orElse(-1);
        promedio = Math.round(promedio * 100.0) / 100.0;


        if (numeros.size() >= 3) {

            for (int j = 0; j < numeros.size(); j++) {
                num = numeros.get(j);

                if (num < menorNota) {
                    menorNota = num;

                }

                if (num > mayorNota) {
                    mayorNota = num;

                }
            }
        }


        System.out.println("El promedio de notas es: " + promedio);
        System.out.println("La calificacion menor es: " + menorNota);
        System.out.println("La Calificacion mayor es: " + mayorNota);
        System.out.println("----------------------------------------");


        // Datos Modificados


        System.out.println("### Datos Modificados ###");

        for (int i = numeros.size() - 1; i >= 0; i--) {
            if (numeros.get(i) % 2 == 0) {
                numeros.remove(i);
            }
        }

        promedio = numeros.stream().mapToDouble(e -> e).average().orElse(-1);
        promedio = Math.round(promedio * 100.0) / 100.0;


        System.out.println("El promedio de notas es: " + promedio);
        System.out.println("La calificacion menor es: " + menorNota);
        System.out.println("La Calificacion mayor es: " + mayorNota);
        System.out.println("----------------------------------------");
    }


}
